using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Vectrosity;
/*
参考游戏： 交叉线!
https://www.taptap.com/app/64361

线段交叉算法：
https://www.cnblogs.com/sparkleDai/p/7604895.html
https://blog.csdn.net/rickliuxiao/article/details/6259322

*/


public class LineInfo
{
    public List<Vector3> listPoint;
    public VectorLine line;
    public int idxStart;
    public int idxEnd;

}

public class GameStick : GameBase
{
    public const float RATIO_RECT = 0.9f;


    /// Awake is called when the script instance is being loaded.
    /// </summary>
    void Awake()
    {

        LayOut();
    }
    /// <summary>
    /// Start is called on the frame when a script is enabled just before
    /// any of the Update methods is called the first time.
    /// </summary>
    void Start()
    {
        //  LayOut();
    }
    public override void LayOut()
    {
        float x, y, z, w, h;
        Vector2 sizeWorld = Common.GetWorldSize(mainCam);
        Vector2 sizeCanvas = this.frame.size;
        float ratio = 1f;
        if (sizeCanvas.x <= 0)
        {
            return;
        }

    }
    public override void UpdateGuankaLevel(int level)
    {
        CrossItemInfo info = (CrossItemInfo)GameGuankaParse.main.GetGuankaItemInfo(level);
        // letterConnect = (LetterConnect)GameObject.Instantiate(letterConnectPrefab);
        // //AppSceneBase.main.AddObjToMainWorld(letterConnect.gameObject); 
        // letterConnect.transform.SetParent(this.transform);
        // UIViewController.ClonePrefabRectTransform(letterConnectPrefab.gameObject, letterConnect.gameObject);
        // letterConnect.transform.localPosition = new Vector3(0f, 0f, -1f);

        LayOut();
        // LayOut();
        // Invoke("LayOut", 0.6f);
    }

}

