using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIHowToPlayPage3 : UIView
{
    public Text textTitle;
    public Text textDetail;
    public UITips uiTips;

    /// </summary>
    void Awake()
    {
        textTitle.color = AppRes.colorTitle;
        textDetail.color = AppRes.colorTitle;
        //tishi bar
        textTitle.text = Language.main.GetString("STRING_HOWTOPLAY_TITLE3");
        textDetail.text = Language.main.GetString("STRING_HOWTOPLAY_DETAIL3");
        {
            // GameObject obj = PrefabCache.main.Load(AppRes.PREFAB_UITIPS);
            // uiTips = obj.GetComponent<UITips>();
            // uiTips = (UITips)GameObject.Instantiate(uiTips);
            // uiTips.transform.parent = this.transform;
            if (uiTips != null)
            {
                uiTips.UpdateGold(20);
            }
        }
    }
}
