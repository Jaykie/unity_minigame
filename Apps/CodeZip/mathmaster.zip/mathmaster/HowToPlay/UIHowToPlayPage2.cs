using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIHowToPlayPage2 : UIView
{
    public Text textTitle;
    public Text textDetail;
    /// </summary>
    void Awake()
    {
        textTitle.color = AppRes.colorTitle;
        textDetail.color = AppRes.colorTitle;
        //retry
        textTitle.text = Language.main.GetString("STRING_HOWTOPLAY_TITLE2");
        textDetail.text = Language.main.GetString("STRING_HOWTOPLAY_DETAIL2");

    }
}
