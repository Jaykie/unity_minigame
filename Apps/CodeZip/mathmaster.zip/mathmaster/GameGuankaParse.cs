﻿using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System.Text;
public class GameGuankaParse : GuankaParseBase
{
    static private GameGuankaParse _main = null;
    public static GameGuankaParse main
    {
        get
        {
            if (_main == null)
            {
                _main = new GameGuankaParse();
            }
            return _main;
        }
    }
 

    public override ItemInfo GetGuankaItemInfo(int idx)
    { 
        if (listGuanka == null)
        {
            return null;
        }
        if (idx >= listGuanka.Count)
        {
            return null;
        }
        ItemInfo info = listGuanka[idx] as ItemInfo;
        return info;
    }

    public ItemInfo GetItemInfo()
    {
        int idx = LevelManager.main.gameLevel; 
        return GetGuankaItemInfo(idx);
    }
    
      public override int GetGuankaTotal()
    {
        ParseGuanka();
        if (listGuanka != null)
        {
            return listGuanka.Count;
        }
        return 0;
    }

    public override void CleanGuankaList()
    {
        if (listGuanka != null)
        {
            listGuanka.Clear();
        }

    }

    public override int ParseGuanka()
    {
        int count = 0;

        if ((listGuanka != null) && (listGuanka.Count != 0))
        {
            return listGuanka.Count;
        }

        listGuanka = new List<object>();
        int idx = LevelManager.main.placeLevel;
        string fileName = Common.GAME_RES_DIR + "/guanka/guanka_list_place" + idx + ".json";
        //FILE_PATH
        string json = FileUtil.ReadStringAsset(fileName);//((TextAsset)Resources.Load(fileName, typeof(TextAsset))).text;
        // Debug.Log("json::"+json);
        JsonData root = JsonMapper.ToObject(json);
        JsonData items = root["items"];
        for (int i = 0; i < items.Count; i++)
        {
            JsonData item = items[i];
            MathMasterItemInfo info = new MathMasterItemInfo();
            info.title = (string)item["title"];
            info.row = Common.String2Int((string)item["row"]);
            info.col = Common.String2Int((string)item["col"]);


            //array formulation
            JsonData jsonArray = item["formulation"];
            info.listFormulation = new List<object>();
            for (int j = 0; j < jsonArray.Count; j++)
            {
                JsonData jsonValueTmp = jsonArray[j];
                string str = (string)jsonValueTmp;
                List<string> listTmp = MathMasterUtil.mathFormulationString2Array(str);
                info.listFormulation.Add(listTmp);
                //info.listFormulation.Add(str);
            }

            //array mathbox
            jsonArray = item["mathbox"];
            info.listBox = new List<string>();
            for (int j = 0; j < jsonArray.Count; j++)
            {
                JsonData jsonValueTmp = jsonArray[j];
                string str = (string)jsonValueTmp;
                info.listBox.Add(str);
            }


            listGuanka.Add(info);
        }

        count = listGuanka.Count;

        Debug.Log("ParseGame::count=" + count);
        return count;
    }

}
