﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class UIGuankaItemIconDot : UIView
{
    static public Texture2D texDot0;
    static public Texture2D texDot1;

    public Image image;
    /// Awake is called when the script instance is being loaded.
    /// </summary>
    void Awake()
    {
        LoadRes(); 
        int rdm = Random.Range(0, 2);
        image.sprite = LoadTexture.CreateSprieFromTex((rdm > 0) ? texDot0 : texDot1);
    }

    void LoadRes()
    {
        if (texDot0 != null)
        {
            return;
        }
        texDot0 = TextureCache.main.Load(AppRes.IMAGE_GUANKA_ITEM_DOT0);
        texDot1 = TextureCache.main.Load(AppRes.IMAGE_GUANKA_ITEM_DOT1);;

    }
}
