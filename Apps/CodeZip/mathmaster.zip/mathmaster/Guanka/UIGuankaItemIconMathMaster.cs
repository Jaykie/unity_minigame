﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class UIGuankaItemIconMathMaster : UIView
{
    UIGuankaItemIconDot uiDotPrefab;
    public int row;
    public int col;
    List<UIGuankaItemIconDot> listItem;

    /// <summary>
    /// Awake is called when the script instance is being loaded.
    /// </summary>
    void Awake()
    {
        GridLayoutGroup gridLayout = this.GetComponent<GridLayoutGroup>();
        Vector2 cellSize = gridLayout.cellSize;
    }
    void LoadPrefab()
    {
        string strPrefab = "AppCommon/Prefab/Guanka/UIGuankaItemIconDot";
        GameObject obj = PrefabCache.main.Load(strPrefab);
        uiDotPrefab = obj.GetComponent<UIGuankaItemIconDot>();
    }
    public void UpdateItem()
    {
        float x, y, w, h;
        LoadPrefab();
        if (listItem == null)
        {
            listItem = new List<UIGuankaItemIconDot>();
        }
        // int stepx,stepy;
        // stepx = PIC_OFFSET/2;
        // stepy = PIC_OFFSET/2;
        GridLayoutGroup gridLayout = this.GetComponent<GridLayoutGroup>();
        w = this.frame.width / col;
        //Debug.Log("UIGuankaItemIconMathMaster:w="+this.frame.width);
        gridLayout.cellSize = new Vector2(w, w);
        //clean
        foreach (UIGuankaItemIconDot dot in listItem)
        {
            DestroyImmediate(dot.gameObject);
        }
        listItem.Clear();



        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < col; j++)
            {
                UIGuankaItemIconDot uiDot = (UIGuankaItemIconDot)GameObject.Instantiate(uiDotPrefab);
                uiDot.transform.parent = this.transform;
                uiDot.transform.localScale = new Vector3(1f,1f,1f);
                listItem.Add(uiDot);
            }
        }
    }
}
