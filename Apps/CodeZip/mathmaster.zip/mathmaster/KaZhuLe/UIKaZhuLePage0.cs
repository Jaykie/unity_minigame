using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIKaZhuLePage0 : UIView
{
    public GameObject objFormulation;
    public Text textTitle;
    public Text textMid;
    public Text textDetail;
    UICellItemBase cellItemPrefab;
    int heightCell = 128;
    int oneCellNum = 2;
    int totalItem = 2;
    MathMasterItemInfo infoGuanka;
    /// </summary>
    void Awake()
    {
        textTitle.color = AppRes.colorTitle;
        textMid.color = AppRes.colorTitle;
        textDetail.color = AppRes.colorTitle;

        infoGuanka = GameLevelParse.main.GetGuankaItemInfo(3) as MathMasterItemInfo;
        textTitle.text = Language.main.GetString("STRING_HELP_KAZHULE_TITLE0");
        textMid.text = Language.main.GetString("STRING_HELP_KAZHULE_THEN");
        textDetail.text = Language.main.GetString("STRING_HELP_KAZHULE_DETAIL0");
        LoadPrefab();
        AddItem(0);
        AddItem(1);
    }

    void LoadPrefab()
    {
        {
            GameObject obj = PrefabCache.main.Load(AppRes.PREFAB_MathFormulationCellItem);
            cellItemPrefab = obj.GetComponent<UICellItemBase>();
        }

    }

    void AddItem(int idx)
    {
        UICellItemBase item = (UICellItemBase)GameObject.Instantiate(cellItemPrefab);
        item.transform.parent = objFormulation.transform;
        item.transform.localScale = new Vector3(1f, 1f, 1f);
        Rect rc = (item.transform as RectTransform).rect;
        item.width = rc.width / oneCellNum;
        item.height = heightCell;
        item.index = idx;
        item.totalItem = totalItem;
        item.UpdateItem(infoGuanka.listFormulation);
    }
}
