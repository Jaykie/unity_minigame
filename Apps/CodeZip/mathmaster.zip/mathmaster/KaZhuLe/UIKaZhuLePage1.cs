using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIKaZhuLePage1 : UIView
{
    public Text textTitle;
    public Image image;
    public Text textDetail;

    /// <summary>
    /// Awake is called when the script instance is being loaded.
    /// </summary>
    void Awake()
    {
        textTitle.color = AppRes.colorTitle;
        textDetail.color = AppRes.colorTitle;
        textTitle.text = Language.main.GetString("STRING_HELP_KAZHULE_TITLE1");
        textDetail.text = Language.main.GetString("STRING_HELP_KAZHULE_DETAIL1");
    }


}
