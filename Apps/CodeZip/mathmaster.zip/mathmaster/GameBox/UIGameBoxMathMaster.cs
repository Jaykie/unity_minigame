using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public delegate void OnDisplayMathFormulationDelegate(string str, Color color);
public delegate void OnMathFormulationFinishDelegate(bool isAll, string formulation, int idx);
public class UIGameBoxMathMaster : UIView, IPointerUpHandler, IPointerDownHandler, IDragHandler
{


    public GameObject objSpriteBg;

    string strTitleGuanka;
    bool isTouchMove;
    List<object> listItem;
    List<object> listItemSel;
    bool isFirstItemClick;

    int touchOffset;
    bool isActionFinished;
    int itemRow;//行
    int itemCol;//列

    int indexRow;//行
    int indexCol;//列
    float action_time;
    bool isClickDown;

    int index;
    BoxCollider collider;



    //数学式子步数
    int mathFormulationStepNum;

    //formulationbar
    //Array *arrayMathFormulationBar;
    Rect rectFormulationBar;
    int lineTotal;

    //string
    string strMathFormulation;//数学式子字符串
    string strMathFormulationFinish;
    int indexFindFormulation;
    List<object> arrayFormulation;//数学式子数组
    List<object> arrayFormulationTmp;

    bool isFormulationOk;
    bool isFormulationError;

    int rowFormulationOK;
    int colFormulationOK;



    int indexMathFormulationBarUnLock;

    float itemWidth;
    float itemHeight;
    bool isGameReplay;
    bool isAllTiShiUnLock;//所有提升解锁
    MathMasterItemInfo infoItem;
    Color colorNormal = new Color(248 / 255f, 136 / 255f, 22 / 255f, 1f);//248,136,22
    Color colorError = new Color(1f, 0f, 0f, 1f);
    public OnDisplayMathFormulationDelegate callbackDisplay { get; set; }
    public OnMathFormulationFinishDelegate callbackFinish { get; set; }
    /// <summary>
    /// Awake is called when the script instance is being loaded.
    /// </summary>
    void Awake()
    {
        action_time = 0.3f;
        listItem = new List<object>();
        listItemSel = new List<object>();
        arrayFormulation = new List<object>();
        arrayFormulationTmp = new List<object>();
        collider = this.gameObject.GetComponent<BoxCollider>();
    }
    public override void LayOut()
    {
        ReLayoutItems(false);
    }
    void RemoveAllItem()
    {
        foreach (UIGameBoxItemMathMaster item in listItem)
        {
            DestroyImmediate(item.gameObject);
        }
        listItem.Clear();

    }
    void UpdateItemSize()
    {
        int step = 0;
        RectTransform rctran = this.GetComponent<RectTransform>();
        float box_w = rctran.rect.width;
        float box_h = rctran.rect.height;
        collider.size = new Vector3(box_w, box_h, 1f);
        objSpriteBg.GetComponent<SpriteRenderer>().size = new Vector2(box_w, box_h);

        int borderoffset = 0;//RES_GAMEBOX_BG_BORDER_OFFSET; 
        itemWidth = (box_w - borderoffset * 2 - step * (itemCol + 1)) / itemCol;
        itemHeight = (box_h - borderoffset * 2 - step * (itemRow + 1)) / itemRow;

    }
    public void UpdateItem(MathMasterItemInfo info)
    {
        float x, y, w, h;
        isFirstItemClick = true;

        strTitleGuanka = Language.game.GetString("GUANKA_TITLE" + LevelManager.main.gameLevel);//info.title;
        DisplayMathFormulationString(strTitleGuanka, colorNormal, false);

        infoItem = info;
        itemRow = info.row;
        itemCol = info.col;
        Camera cam = AppSceneBase.main.mainCamera;
        UpdateItemSize();
        RemoveAllItem();

        int item_idx = 0;
        RectTransform rctran = this.GetComponent<RectTransform>();
        float box_w = rctran.rect.width;
        float box_h = rctran.rect.height;

        for (int i = 0; i < itemRow; i++)
        {
            for (int j = 0; j < itemCol; j++)
            {
                item_idx = itemCol * i + j;
                string strItem = info.listBox[item_idx];
                if (Common.String2Int(strItem) < 0)
                {
                    continue;
                }
                // x = -box_w / 2 + (itemWidth + step) * j + step + borderoffset;
                // x += itemWidth / 2;
                // y = -box_h / 2 + (itemHeight + step) * i + step + borderoffset;
                // y += itemHeight / 2;

                Vector2 ptLocal = GetItemLocalPos(i, j);
                w = itemWidth;
                h = itemHeight;

                UIGameBoxItemMathMaster item = (UIGameBoxItemMathMaster)GameObject.Instantiate(UIGameMathMaster.uiGameBoxItemPrefab);
                item.transform.parent = this.transform;
                item.index = item_idx;
                item.indexRow = i;
                item.indexCol = j;
                item.indexRowDisp = i;
                item.indexColDisp = j;
                float z = -1f;
                item.posNormal = new Vector3(ptLocal.x, ptLocal.y, z);


                //初始化在屏幕外面
                y = box_h / 2 + (cam.orthographicSize - (this.transform.position.y + box_h / 2)) + itemHeight / 2;
                item.transform.localPosition = new Vector3(ptLocal.x, y, z);
                // item->setRowTmpIndex(i);
                // item->setRowIndex(i);
                // item->setColumnIndex(j);
                // item->setAnchorPoint(Point::ZERO);
                RectTransform rctranItem = item.GetComponent<RectTransform>();
                rctranItem.sizeDelta = new Vector2(itemWidth, itemHeight);

                item.UpdateItem(info);
                item.RunActionShow();

                listItem.Add(item);
            }
        }

    }

    Vector2 GetItemLocalPos(int row, int col)
    {
        Vector2 pt = Vector2.zero;
        int step = 0;
        float x, y;
        int borderoffset = 0;
        RectTransform rctran = this.GetComponent<RectTransform>();
        float box_w = rctran.rect.width;
        float box_h = rctran.rect.height;
        x = -box_w / 2 + (itemWidth + step) * col + step + borderoffset;
        x += itemWidth / 2;
        y = -box_h / 2 + (itemHeight + step) * row + step + borderoffset;
        y += itemHeight / 2;
        pt.x = x;
        pt.y = y;
        return pt;
    }
    void ReLayoutItems(bool isShowAction)
    {
        float x, y, w, h;
        UpdateItemSize();
        Debug.Log("ReLayoutItems");
        for (int k = 0; k < listItem.Count; k++)
        {
            UIGameBoxItemMathMaster item = (UIGameBoxItemMathMaster)listItem[k];
            int i, j;
            RectTransform rctranItem = item.GetComponent<RectTransform>();
            rctranItem.sizeDelta = new Vector2(itemWidth, itemHeight);
            i = item.indexRowDisp;
            j = item.indexColDisp;
            item.index = infoItem.col * i + j;

            Vector3 ptLocal = GetItemLocalPos(i, j);
            ptLocal.z = item.transform.localPosition.z;
            if (isShowAction)
            {
                Debug.Log("item=" + item.transform.localPosition + " new=" + ptLocal);
                RunActionFall(item, ptLocal);
            }
            else
            {
                float z = item.transform.localPosition.z;
                item.transform.localPosition = new Vector3(ptLocal.x, ptLocal.y, z);
            }

            item.LayOut();
            // 
        }
    }

    void DisplayMathFormulationString(string str, Color color, bool isFormat)
    {
        if (this.callbackDisplay != null)
        {
            string str_new = str;
            if (isFormat)
            {
                str_new = MathMasterUtil.mathFormulationStringFormat(str);
            }

            //Debug.Log("old:" + str + "\nnew:" + str_new);
            this.callbackDisplay(str_new, color);
        }
    }


    UIGameBoxItemMathMaster GetItemByRowCol(int r, int c)
    {
        UIGameBoxItemMathMaster itemret = null;
        foreach (UIGameBoxItemMathMaster item in listItem)
        {
            if ((r == item.indexRow) && (c == item.indexCol))
            {
                itemret = item;
                break;
            }
        }

        return itemret;
    }

    //最顶层的z坐标
    float GetTheMostTopItemPosZ()
    {
        float z = 0f;
        foreach (UIGameBoxItemMathMaster item in listItem)
        {
            float z_item = item.transform.localPosition.z;
            if (z_item < z)
            {
                z = z_item;
            }
        }

        return z;
    }

    void RemoveOneItem(UIGameBoxItemMathMaster item)
    {
        int row = item.indexRowDisp;//
        int col = item.indexCol;
        for (int i = (row + 1); i < infoItem.row; i++)
        {
            int item_idx = infoItem.col * i + col;

            UIGameBoxItemMathMaster itemtmp = GetItemByRowCol(i, col);
            if (itemtmp)
            {
                //纪录每次向下移动一格 
                itemtmp.indexRowDisp--;
                if (itemtmp.indexRowDisp < 0)
                {
                    itemtmp.indexRowDisp = 0;
                }
            }
        }
        DestroyImmediate(item.gameObject);
    }
    void RemoveAllSelItem()
    {
        isActionFinished = false;
        foreach (UIGameBoxItemMathMaster item in listItemSel)
        {
            listItem.Remove(item);
            RemoveOneItem(item);
        }
        listItemSel.Clear();

        if (listItem.Count != 0)
        {
            //其他项重新排列位置
            ReLayoutItems(true);
            OnFormulationFinish(false);
        }
        else
        {
            OnFormulationFinish(true);
        }



    }


    //移动“选中项”到gamebox中央动画
    void RunActionMovetoCenter()
    {

        RectTransform rctran = this.GetComponent<RectTransform>();
        Rect frame = rctran.rect;

        int n = listItemSel.Count;
        float offset_left_right1 = frame.width / 10;
        float step1 = (frame.width - offset_left_right1 * 2 - itemWidth) / (n - 1);

        float offset_left_right2 = frame.width / 4;
        float step2 = (frame.width - offset_left_right2 * 2 - itemWidth) / (n - 1);

        for (int i = 0; i < n; i++)
        {
            UIGameBoxItemMathMaster item = (UIGameBoxItemMathMaster)listItemSel[i];
            item.UpdateItemStatus(UIGameBoxItemMathMaster.ItemStatus.ANIMATION);

            //置顶显示
            item.transform.SetAsLastSibling();
            float z_top = GetTheMostTopItemPosZ();
            Vector3 pos_tmp = item.transform.localPosition;
            pos_tmp.z = z_top - 1;
            item.transform.localPosition = pos_tmp;


            float z = item.transform.position.z;
            Vector3 pt1 = Vector3.zero, pt2 = Vector3.zero, pt3 = Vector3.zero;
            float start_x = this.transform.position.x - rctran.rect.width / 2;
            //float start_y = this.transform.position.y - rctran.rect.height / 2;

            pt1.x = start_x + offset_left_right1 + step1 * i + itemWidth / 2;
            pt1.y = this.transform.position.y;
            pt1.z = z;

            pt2.x = start_x + offset_left_right2 + step2 * i + itemWidth / 2;
            pt2.y = this.transform.position.y;
            pt2.z = z;


            if (Device.isLandscape)
            {
                pt3.x = -Common.GetCameraWorldSizeWidth(mainCam) + itemWidth / 2;
                pt3.y = this.transform.position.y;

            }
            else
            {
                pt3.x = this.transform.position.x;
                pt3.y = -mainCam.orthographicSize + itemHeight / 2;

            }
            pt3.z = z;

            // if (delegate) {
            //     pt3 = delegate->UIViewMathGameBoxGetFallPosition(this,item);
            // }


            // ActionInterval *action = (ActionInterval*)Sequence::create
            // (
            //  MoveTo::create(action_time,pt1),
            //  DelayTime::create(action_time*2),
            //  MoveTo::create(action_time,pt2),
            //   MoveTo::create(action_time,pt3),
            //  CallFunc::create(this, callfunc_selector(UIViewMathGameBox::actionMoveSelItemFinish)),
            //  NULL
            //  );



            iTween.MoveTo(item.gameObject, iTween.Hash("islocal", false, "position", pt1, "time", action_time, "delay", 0f, "easeType", iTween.EaseType.easeInSine));
            iTween.MoveTo(item.gameObject, iTween.Hash("islocal", false, "position", pt2, "time", action_time, "delay", action_time * 3, "easeType", iTween.EaseType.easeInSine));
            iTween.MoveTo(item.gameObject, iTween.Hash("islocal", false, "position", pt3, "time", action_time, "delay", action_time * 4, "easeType", iTween.EaseType.easeInSine, "oncompletetarget", this.gameObject, "oncomplete", "ActionMovetoCenterFinish"));
        }

    }

    void ActionMovetoCenterFinish()
    {
        RemoveAllSelItem();
        AudioPlay.main.PlayFile(AppRes.AUDIO_WORD_OK);
    }

    //重新排练消除下落动画
    void RunActionFall(UIGameBoxItemMathMaster item, Vector3 pt)
    {
        iTween.MoveTo(item.gameObject, iTween.Hash("islocal", true, "position", pt, "time", action_time, "delay", 0f, "easeType", iTween.EaseType.easeInSine, "oncompletetarget", this.gameObject, "oncomplete", "ActionFallFinish"));
    }

    void ActionFallFinish()
    {

        if (isActionFinished)
        {
            return;
        }

        isActionFinished = true;

        if (listItem.Count == 0)
        {
            //OnGameWin();
        }

    }

    void OnFormulationFinish(bool isAll)
    {
        //game win
        if (this.callbackFinish != null)
        {
            this.callbackFinish(isAll, strMathFormulationFinish, indexFindFormulation);
        }
    }

    void OnStartAddItem()
    {
        isFormulationOk = false;
        isFormulationError = false;
        strMathFormulation = "";
        DisplayMathFormulationString(strMathFormulation, colorNormal, true);
        arrayFormulation.Clear();
    }
    void OnDidAddItem(UIGameBoxItemMathMaster item)
    {
        if (isFormulationOk)
        {
            //运算正确之后再滑动清除
            isFormulationOk = false;
        }
        string strLast = "";
        if (arrayFormulation.Count > 0)
        {
            strLast = (string)arrayFormulation[arrayFormulation.Count - 1];
        }

        strMathFormulation += item.strItem;

        bool isLastNumAndOperator = false;
        if (((!(Common.BlankString(strLast))) && (MathMasterUtil.isMathOperator(item.strItem)) && (!(MathMasterUtil.isMathOperator(strLast)))))
        {
            //数字后面的运算符不显示
            isLastNumAndOperator = true;
        }

        arrayFormulation.Add(item.strItem);
        string strTitle = "";
        bool isError = MathMasterUtil.isMathFormulationError(arrayFormulation);
        Color color = colorNormal;
        if (isError)
        {
            isFormulationError = true;
            strTitle = strMathFormulation + "=ERROR";

            color = colorError;
        }
        else
        {

            if (arrayFormulation.Count < MathMasterUtil.MATH_FORMULATION_NUM_MIN)
            {
                //还没有运算结果
                strTitle = strMathFormulation;
                if (isLastNumAndOperator)
                {
                    // int len = strlen(ptmp);
                    // if (len)
                    // {
                    //     char* p = ptmp + (len - 1);
                    //     *p = 0;
                    // }

                }

            }
            else
            {
                arrayFormulationTmp.Clear();
                foreach (object obj in arrayFormulation)
                {
                    arrayFormulationTmp.Add(obj);
                }

                int ret = MathMasterUtil.mathFormulationForString(arrayFormulationTmp);
                strTitle = strMathFormulation;
                if (isLastNumAndOperator)
                {
                    // int len = strlen(ptmp);
                    // if (len)
                    // {
                    //     char* p = ptmp + (len - 1);
                    //     *p = 0;
                    // }

                }
                strTitle += "=" + ret.ToString();


                if (ret == 0)
                {
                    //正确
                    isFormulationOk = true;

                }
            }

        }

        DisplayMathFormulationString(strTitle, color, true);

    }

    void OnItemTouchMove(UIGameBoxItemMathMaster item)
    {

        int row = item.indexRow;
        int col = item.indexCol;
        // log("row=%d,col=%d,visible=%d",row,col,view->isVisible());
        if (!item.gameObject.activeSelf)
        {
            return;
        }
        if (isFirstItemClick)
        {
            isFirstItemClick = false;

            listItemSel.Clear();
            OnStartAddItem();
        }
        else
        {
            //判断和最后一个是否相邻
            if (listItemSel.Count > 0)
            {
                UIGameBoxItemMathMaster itemLast = (UIGameBoxItemMathMaster)listItemSel[listItemSel.Count - 1];
                if (itemLast)
                {
                    int step_row = Mathf.Abs(itemLast.indexRowDisp - item.indexRowDisp);
                    int step_col = Mathf.Abs(itemLast.indexColDisp - item.indexColDisp);
                    if ((step_row > 1) || step_col > 1)
                    {
                        return;
                    }

                }
            }
        }

        if (!listItemSel.Contains(item))
        {
            item.UpdateItemStatus(UIGameBoxItemMathMaster.ItemStatus.SEL);
            listItemSel.Add(item);
            OnDidAddItem(item);
        }

    }



    void OnItemTouchUp()
    {
        indexFindFormulation = 0;
        if (isFormulationOk)
        {
            isFormulationOk = false;
            // //查询正确答案

            bool isFind = MathMasterUtil.isFindMathFormulation(strMathFormulation, infoItem.listFormulation, out indexFindFormulation);

            rowFormulationOK = 0;
            colFormulationOK = 0;
            if (isFind)
            {
                strMathFormulationFinish = strMathFormulation;
                //清除显示
                strMathFormulation = "";
                OnMathFormulationOK();
            }
            else
            {
                //没有找到答案
                OnMathFormulationError();
            }


        }
        else
        {
            //运算式子错误
            OnMathFormulationError();

        }

        DisplayMathFormulationString(strTitleGuanka, colorNormal, false);
    }

    //错误答案
    void OnMathFormulationError()
    {
        //
        // viewMathGameBox->onClickUp();
        foreach (UIGameBoxItemMathMaster item in listItemSel)
        {
            item.RunActionError();
        }
        AudioPlay.main.PlayFile(AppRes.AUDIO_WORD_FAIL);

    }

    //得到正确答案
    void OnMathFormulationOK()
    {
        // rowFormulationOK = viewBar->getRowIndex();
        // colFormulationOK = viewBar->getColIndex();
        // viewBar->setUnLockAll();
        arrayFormulation.Clear();
        RunActionMovetoCenter();
    }


    void CheckTouchSelect()
    {
        float x, y, w, h;
        foreach (UIGameBoxItemMathMaster item in listItem)
        {
            RectTransform rctran = item.GetComponent<RectTransform>();
            float ratio = 0.8f;
            w = rctran.rect.width * ratio;
            h = rctran.rect.height * ratio;
            x = item.transform.position.x;
            y = item.transform.position.y;

            Vector2 posTouch = mainCam.ScreenToWorldPoint(Common.GetInputPosition());
            Rect rc = new Rect(x - w / 2, y - h / 2, w, h);
            if (rc.Contains(posTouch) && this.gameObject.activeSelf)
            {
                //选中
                if (!item.isTouchSel)
                {
                    item.isTouchSel = true;
                    AudioPlay.main.PlayFile(AppRes.AUDIO_LETTER_DRAG_1);
                    OnItemTouchMove(item);
                }
                // isClickDown = true;
            }
        }


    }
    //相当于touchDown
    public void OnPointerDown(PointerEventData eventData)
    {
        Debug.Log("UIGameBoxMathMaster::OnPointerDown POS= " + eventData.position);
        CheckTouchSelect();
    }
    //相当于touchUp
    public void OnPointerUp(PointerEventData eventData)
    {
        isClickDown = false;
        isFirstItemClick = true;
        foreach (UIGameBoxItemMathMaster item in listItem)
        {

            item.isTouchSel = false;
        }
        OnItemTouchUp();

        // if (delegate)
        // { 
        //     delegate->UIViewMathGameBoxTouchUp(this);
        // }
    }
    //相当于touchMove
    public void OnDrag(PointerEventData eventData)
    {
        CheckTouchSelect();
    }


}
