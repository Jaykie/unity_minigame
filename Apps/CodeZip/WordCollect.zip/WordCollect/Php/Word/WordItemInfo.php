﻿<?php
class WordItemInfo
{
    public $title;
    public $translation; //array 
    public $change; //变形

    //例句
}
