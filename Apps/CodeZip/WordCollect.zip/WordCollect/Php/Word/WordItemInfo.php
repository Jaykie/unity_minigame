﻿<?php
class WordItemInfo
{ 
    public $id;
    public $title;
    public $translation; //array 
    public $change; //变形

    //例句
}
