﻿using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System.Text;

public class GameRes
{
    public const string PREFAB_LETTER_ITEM = "AppCommon/Prefab/Game/UILetterItem";

}
