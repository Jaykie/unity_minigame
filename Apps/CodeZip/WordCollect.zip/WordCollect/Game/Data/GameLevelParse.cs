﻿using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System.Text;

public class PoemContentInfo
{
    public string content;
    public string pinyin;
    public bool skip;
}
public class WordItemInfo : ItemInfo
{
    public string[] listLetter;
    public string[] listAnswer;//答案 LO|SOL 
    public List<AnswerInfo> listAnswerInfo;
    public List<List<object>> listBoard;//top t0 bottom 排列
    public string[] listError;
    public string author;
    public string year;
    public string style;
    public string album;
    public string intro;
    public string translation;
    public string appreciation;
    public string pinyin;
    public string head;
    public string end;
    public string tips;
    public string change;

    public List<PoemContentInfo> listPoemContent;

    //idiomconnet
    public List<string> listWord;
    public List<string> listIdiom;
    public List<int> listPosX;
    public List<int> listPosY;
    public List<int> listWordAnswer;

    public string date;
    public string addtime;

    public DBItemInfoBase dbInfo;
    // public IdiomItemInfo dbIdiomInfo;

}
public class GameLevelParse : LevelParseBase
{
    public string strWord3500;
    Language languageGame;
    GameLevelParseBase levelParse;
    static private GameLevelParse _main = null;
    public static GameLevelParse main
    {
        get
        {
            if (_main == null)
            {
                _main = new GameLevelParse();
                _main.UpdateLanguage();
            }
            return _main;
        }
    }


    public override ItemInfo GetGuankaItemInfo(int idx)
    {
        if (listGuanka == null)
        {
            return null;
        }
        if (idx >= listGuanka.Count)
        {
            return null;
        }
        ItemInfo info = listGuanka[idx] as ItemInfo;
        return info;
    }

    public WordItemInfo GetItemInfo()
    {
        int idx = LevelManager.main.gameLevel;
        return GetGuankaItemInfo(idx) as WordItemInfo;
    }


    public bool IsPunctuation(string str)
    {
        bool ret = false;

        foreach (string item in GameLevelParseBase.arrayPunctuation)
        {
            if (str == item)
            {
                ret = true;
                break;
            }
        }
        return ret;
    }

    //非标点符号文字
    public List<int> IndexListNotPunctuation(string str)
    {
        List<int> listRet = new List<int>();

        int len = str.Length;
        for (int i = 0; i < len; i++)
        {
            string word = str.Substring(i, 1);
            if (!IsPunctuation(word))
            {
                listRet.Add(i);
            }

        }
        return listRet;
    }
    public void UpdateLanguage()
    {
        ItemInfo info = LevelManager.main.GetPlaceItemInfo(LevelManager.main.placeLevel);
        string strlan = CloudRes.main.rootPathGameRes + "/language/" + info.language + ".csv";
        languageGame = new Language();
        languageGame.Init(strlan);
        languageGame.SetLanguage(SystemLanguage.Chinese);
    }

    public override int GetGuankaTotal()
    {
        ParseGuanka();
        if (listGuanka != null)
        {
            return listGuanka.Count;
        }
        return 0;
    }

    public override void CleanGuankaList()
    {
        if (listGuanka != null)
        {
            listGuanka.Clear();
        }

    }

    int GetRandomOtherLevelIndex(int level)
    {
        int total = listGuanka.Count;
        int size = total - 1;
        int[] idxTmp = new int[size];
        int idx = 0;
        for (int i = 0; i < total; i++)
        {
            if (i != level)
            {
                idxTmp[idx++] = i;
            }
        }

        int rdm = Random.Range(0, size);
        if (rdm >= size)
        {
            rdm = size - 1;
        }
        idx = idxTmp[rdm];
        return idx;
    }


    public override int ParseGuanka()
    {
        int count = 0;
        ItemInfo infoPlace = LevelManager.main.GetPlaceItemInfo(LevelManager.main.placeLevel);
        Debug.Log("ParseGuanka infoPlace.gameType=" + infoPlace.gameType + " infoPlace.id=" + infoPlace.id);
        if (Common.BlankString(infoPlace.gameId))
        {

        }


        switch (infoPlace.gameId)
        {
            case GameRes.GAME_WORDCONNECT:
                {
                    levelParse = LevelParseWordConnect.main;
                }
                break;

            case GameRes.GAME_CONNECT:
                {
                    levelParse = LevelParseConnect.main;
                }
                break;

            case GameRes.GAME_IDIOM:
                {
                    levelParse = LevelParseIdiom.main;
                }
                break;
            case GameRes.GAME_RIDDLE:
                {
                    levelParse = LevelParseRiddle.main;
                }
                break;
            case GameRes.GAME_Xiehouyu:
                {
                    levelParse = LevelParseXiehouyu.main;
                }
                break;

            case GameRes.GAME_POEM:
                {

                }
                break;
        
            default:
                {
                    levelParse = LevelParseWordConnect.main;
                    if (Common.appKeyName == GameRes.GAME_Kids)
                    {
                        infoPlace.gameId = GameRes.GAME_Kids;
                    }
                }
                break;
        }

        if (levelParse != null)
        {
            count = levelParse.ParseGuanka();
            listGuanka = levelParse.listGuanka;
        }

        return count;
    }
    public int ParseGuanka2()
    {
        int count = 0;
        ItemInfo infoPlace = LevelManager.main.GetPlaceItemInfo(LevelManager.main.placeLevel);
        Debug.Log("ParseGuanka infoPlace.gameType=" + infoPlace.gameType);


        if (Common.appKeyName == GameRes.GAME_WORDCONNECT)
        {
            levelParse = LevelParseWordConnect.main;
        }
        else if (Common.appKeyName == GameRes.GAME_CONNECT)
        {
            levelParse = LevelParseWordConnect.main;
        }
        else
        {
            levelParse = LevelParseWordConnect.main;
        }

        if (levelParse != null)
        {
            count = levelParse.ParseGuanka();
            listGuanka = levelParse.listGuanka;
        }

        return count;
    }

    public void ParseItem(WordItemInfo info)
    {

        if (levelParse != null)
        {
            levelParse.ParseItem(info);
        }

    }
    public void UpdateLetterString(int idx)
    {
        WordItemInfo info = GetItemInfo();
        if (Common.appKeyName == GameRes.GAME_WORDCONNECT)
        {
            return;
        }

        string word = GameAnswer.main.GetGuankaAnswer(info, false, idx);
        info.listLetter = new string[word.Length];
        for (int k = 0; k < word.Length; k++)
        {
            info.listLetter[k] = word.Substring(k, 1);
        }
        Debug.Log("word = UpdateLetterString =" + word);
    }


    public int ParseGuankaWordConnectList()
    {
        int count = 0;

        if ((listGuanka != null) && (listGuanka.Count != 0))
        {
            return listGuanka.Count;
        }

        listGuanka = new List<object>();
        int idx = LevelManager.main.placeLevel;
        string fileName = CloudRes.main.rootPathGameRes + "/guanka/Chapter_" + (idx + 1) + ".txt";
        //FILE_PATH
        string json = FileUtil.ReadStringAsset(fileName);//((TextAsset)Resources.Load(fileName, typeof(TextAsset))).text;
                                                         // Debug.Log("json::"+json);
        JsonData root = JsonMapper.ToObject(json);
        JsonData items = root["levels"];
        /*
             "n": "1",
            "o": 0,
            "l": "L|O|S",
            "r": "LO|SOL",
            "e": ""
         */
        char[] charSplit = { '|' };

        for (int i = 0; i < items.Count; i++)
        {
            JsonData item = items[i];
            WordItemInfo info = new WordItemInfo();
            // info.dbIdiomInfo = new IdiomItemInfo();
            info.dbInfo = new DBWordItemInfo();
            string str = (string)item["l"];

            info.listLetter = str.Split(charSplit);

            str = (string)item["r"];
            info.listAnswer = str.Split(charSplit);
            info.listAnswerInfo = new List<AnswerInfo>();
            for (int j = 0; j < info.listAnswer.Length; j++)
            {
                AnswerInfo infoanswer = new AnswerInfo();
                infoanswer.word = info.listAnswer[j];
                info.listAnswerInfo.Add(infoanswer);
            }

            str = (string)item["e"];
            info.listError = str.Split(charSplit);

            info.gameType = GameRes.GAME_TYPE_WORDLIST;

            listGuanka.Add(info);
        }

        count = listGuanka.Count;

        Debug.Log("ParseGame::count=" + count);
        return count;
    }





}
