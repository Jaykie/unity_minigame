﻿using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System.Text;

public class LevelParseWordConnect : GameLevelParseBase
{
    static private LevelParseWordConnect _main = null;
    public static LevelParseWordConnect main
    {
        get
        {
            if (_main == null)
            {
                _main = new LevelParseWordConnect();
            }
            return _main;
        }
    }

    public override int ParseGuanka()
    {
        int count = 0;
        if (Common.appKeyName != GameRes.GAME_WORDCONNECT)
        {
            return ParseGuankaDefault();
        }
 
        if ((listGuanka != null) && (listGuanka.Count != 0))
        {
            return listGuanka.Count;
        }

        listGuanka = new List<object>();
        int idx = LevelManager.main.placeLevel;
        string fileName = CloudRes.main.rootPathGameRes + "/guanka/Chapter_" + (idx + 1) + ".txt";
        //FILE_PATH
        string json = FileUtil.ReadStringAsset(fileName);//((TextAsset)Resources.Load(fileName, typeof(TextAsset))).text;
                                                         // Debug.Log("json::"+json);
        JsonData root = JsonMapper.ToObject(json);
        JsonData items = root["levels"];
        /*
             "n": "1",
            "o": 0,
            "l": "L|O|S",
            "r": "LO|SOL",
            "e": ""
         */
        char[] charSplit = { '|' };

        for (int i = 0; i < items.Count; i++)
        {
            JsonData item = items[i];
            WordItemInfo info = new WordItemInfo();
            // info.dbIdiomInfo = new IdiomItemInfo();
            info.dbInfo = new DBWordItemInfo();
            string str = (string)item["l"];

            info.listLetter = str.Split(charSplit);

            str = (string)item["r"];
            info.listAnswer = str.Split(charSplit);
            info.listAnswerInfo = new List<AnswerInfo>();
            for (int j = 0; j < info.listAnswer.Length; j++)
            {
                AnswerInfo infoanswer = new AnswerInfo();
                infoanswer.word = info.listAnswer[j];
                info.listAnswerInfo.Add(infoanswer);
            }

            str = (string)item["e"];
            info.listError = str.Split(charSplit);

            info.gameType = GameRes.GAME_TYPE_WORDLIST;

            listGuanka.Add(info);
        }

        count = listGuanka.Count;

        Debug.Log("LevelParseWordConnect ParseGame::count=" + count);
        return count;
    }

    public override void ParseItem(WordItemInfo info)
    {
        Debug.Log("ParseItem info.id=" + info.id);
        ItemInfo infoPlace = LevelManager.main.GetPlaceItemInfo(LevelManager.main.placeLevel);
     

    }



}
