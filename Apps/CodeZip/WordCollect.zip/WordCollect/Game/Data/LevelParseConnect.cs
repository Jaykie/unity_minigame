﻿using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System.Text;

public class LevelParseConnect : GameLevelParseBase
{
    static private LevelParseConnect _main = null;
    public static LevelParseConnect main
    {
        get
        {
            if (_main == null)
            {
                _main = new LevelParseConnect();
            }
            return _main;
        }
    }

    //接龙 
    public override int ParseGuanka()

    {
        int count = 0;

        if ((listGuanka != null) && (listGuanka.Count != 0))
        {
            return listGuanka.Count;
        }

        listGuanka = new List<object>();
        int idx = LevelManager.main.placeLevel;
        ItemInfo infoPlace = LevelManager.main.GetPlaceItemInfo(idx);
        string filepath = CloudRes.main.rootPathGameRes + "/guanka/guanka_list_place" + idx + ".json";
        if (!FileUtil.FileIsExistAsset(filepath))
        {
            filepath = CloudRes.main.rootPathGameRes + "/guanka/item_" + infoPlace.id + ".json";
        }

        //FILE_PATH
        string json = FileUtil.ReadStringAsset(filepath);//((TextAsset)Resources.Load(fileName, typeof(TextAsset))).text;
                                                         // Debug.Log("json::"+json);
        JsonData root = JsonMapper.ToObject(json);

        char[] charSplit = { '|' };

        for (int i = 0; i < root.Count; i++)
        {
            WordItemInfo info = new WordItemInfo();
            //info.dbIdiomInfo = new IdiomItemInfo();
            info.dbInfo = new DBWordItemInfo();

            JsonData item = root[i];
            JsonData itemData = item["data"];
            JsonData letters = itemData["letters"];

            info.listLetter = new string[letters.Count];
            for (int j = 0; j < letters.Count; j++)
            {
                info.listLetter[j] = (string)letters[j];
            }


            JsonData board = itemData["board"];
            info.listBoard = new List<List<object>>();
            for (int j = 0; j < board.Count; j++)
            {
                List<object> ls = new List<object>();
                JsonData it = board[j];
                for (int k = 0; k < it.Count; k++)
                {
                    ls.Add((string)it[k]);
                }
                info.listBoard.Add(ls);

            }
            ParseWordAnswer(info);
            //  info.listAnswer = str.Split(charSplit);

            info.gameType = GameRes.GAME_TYPE_CONNECT;
            listGuanka.Add(info);
        }

        count = listGuanka.Count;

        Debug.Log("ParseGame::count=" + count);
        return count;
    }
    public void ParseWordAnswer(WordItemInfo info)
    {
        int row = info.listBoard.Count;
        int col = info.listBoard[0].Count;

        info.listAnswerInfo = new List<AnswerInfo>();

        for (int i = 0; i < row; i++)
        {

            string str = GetWordFromBoard(info, i, true);
            if (!Common.BlankString(str) && (str.Length > 1))
            {
                AnswerInfo infoanswer = new AnswerInfo();
                infoanswer.word = str;
                infoanswer.row = i;
                infoanswer.col = -1;
                info.listAnswerInfo.Add(infoanswer);
            }
        }

        for (int i = 0; i < col; i++)
        {
            string str = GetWordFromBoard(info, i, false);
            if (!Common.BlankString(str) && (str.Length > 1))
            {
                AnswerInfo infoanswer = new AnswerInfo();
                infoanswer.word = str;
                infoanswer.row = -1;
                infoanswer.col = i;
                info.listAnswerInfo.Add(infoanswer);
            }
        }

        info.listAnswer = new string[info.listAnswerInfo.Count];
        for (int i = 0; i < info.listAnswerInfo.Count; i++)
        {
            AnswerInfo infoanswer = info.listAnswerInfo[i];
            info.listAnswer[i] = infoanswer.word;
        }

    }
    public override void ParseItem(WordItemInfo info)
    { 
                // DBIdiom.main.GetItemById(info.dbInfo, info.id);

                DBWord.main.GetItemById(info.id);
        //  IdiomItemInfo infoIdiom = DBIdiom.main.GetItemByTitle(info.id);
        // info.title = infoIdiom.title;
        // info.album = infoIdiom.album;
        // info.translation = infoIdiom.translation;
        // info.pinyin = infoIdiom.pronunciation;
        // info.dbIdiomInfo = infoIdiom;

    }


    public string GetWordFromBoard(WordItemInfo info, int idx, bool isByRow)
    {
        string ret = "";
        List<object> ls = null;
        bool isEnd = false;
        bool isError = false;
        int count = 0;
        if (isByRow)
        {
            ls = info.listBoard[idx];
            count = ls.Count;
        }
        else
        {
            count = info.listBoard.Count;
        }
        for (int i = 0; i < count; i++)
        {
            string str = "";
            if (isByRow)
            {
                str = (string)ls[i];
            }
            else
            {
                ls = info.listBoard[i];
                str = (string)ls[idx];
            }


            if (!Common.BlankString(str))
            {
                if (!isEnd)
                {
                    ret += str;
                }
                else
                {
                    //有效字符不连续为非答案
                    isError = true;
                }
            }
            else
            {
                if (!Common.BlankString(ret))
                {
                    //检测到空表示结束
                    isEnd = true;
                    break;
                }
            }
        }

        if (isError)
        {
            ret = "";
        }
        return ret;
    }

}
