﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
public class DBWord : DBBaseWord
{
    // public const string TABLE_NAME = "TableIdiom";  

     string[] item_col = new string[] { KEY_id, KEY_title, KEY_translation, KEY_change, };
 
    static DBWord _main = null;
    static bool isInited = false;
    public static DBWord main
    {
        get
        {
            if (_main == null)
            {
                _main = new DBWord();
                Debug.Log("DBWord main init");
                _main.TABLE_NAME = "TableWord";
                _main.dbFileName = "Word_" + Common.appKeyName + ".db";
                _main.Init();
            }
            return _main;
        }

    }
 

    public void Init()
    {
        isNeedCopyFromAsset = false;
        if (Application.isEditor || Common.isiOS)
        {
            CopyDbFileFromResource();
        }
        CreateDb();
        CreateTable(item_col);
    }

  public override void AddItem(DBWordItemInfo info)
    {
        OpenDB();
        int lengh = item_col.Length;
        string[] values = new string[lengh];
        //id,filesave,date,addtime 
        values[0] = info.id;
        //values[0] = "性";//ng

        values[1] = info.title;
        values[2] = info.translation;
        values[3] = info.change;
        // int year = System.DateTime.Now.Year;
        // int month = System.DateTime.Now.Month;
        // int day = System.DateTime.Now.Day;
        // string str = year + "." + month + "." + day;
        // Debug.Log("date:" + str);
        // values[lengh - 2] = str;
        // long time_ms = Common.GetCurrentTimeMs();//GetCurrentTimeSecond
        // values[lengh - 1] = time_ms.ToString();


        dbTool.InsertInto(TABLE_NAME, values);

        CloseDB();
        //  GetItemsByWord();


    }

    public override void ReadInfo(DBWordItemInfo info, SqlInfo infosql)
    {
        info.id = dbTool.GetString(infosql, KEY_id);
        info.title = dbTool.GetString(infosql, KEY_title);
        info.translation = dbTool.GetString(infosql, KEY_translation);
        info.change = dbTool.GetString(infosql, KEY_change);

        // info.pinyin = rd.GetString(KEY_pinyin);
        // Debug.Log("ReadInfo info.pinyin=" + info.pinyin);
        /* 

        */
        // info.addtime = dbTool.GetString(infosql, KEY_addtime);
        // info.date = dbTool.GetString(infosql, KEY_date);
    }
    public List<WordItemInfo> GetAllWord()
    {

        string strsql = "select DISTINCT id from " + TABLE_NAME + " order by addtime desc";

        List<WordItemInfo> listRet = new List<WordItemInfo>();
        OpenDB();
        //SqliteDataReader reader = dbTool.ReadFullTable(TABLE_NAME);//
        SqlInfo infosql = dbTool.ExecuteQuery(strsql, false);
        Debug.Log("GetAllItem start read");
        bool ret = dbTool.MoveToFirst(infosql);
        if (ret == false)
        {
            return listRet;
        }
        while (true)// 循环遍历数据 
        {
            Debug.Log("GetAllItem reading");
            DBWordItemInfo infoDB = new DBWordItemInfo();
            // ReadInfo(infoDB, infosql);
            infoDB.id = dbTool.GetString(infosql, KEY_id);
            WordItemInfo info = new WordItemInfo();
            info.id = infoDB.id;
            info.dbInfo = infoDB;
            listRet.Add(info);
            if (!dbTool.MoveToNext(infosql))
            {
                break;
            }
        }

        // reader.Release();

        CloseDB();
        Debug.Log("GetAllItem:" + listRet.Count);
        return listRet;

    }

    public List<WordItemInfo> GetAllDate()
    {
        // Distinct 去掉重复
        //desc 降序 asc 升序 
        string strsql = "select DISTINCT date from " + TABLE_NAME + " order by addtime desc";


        List<WordItemInfo> listRet = new List<WordItemInfo>();
        OpenDB();
        //SqliteDataReader reader = dbTool.ReadFullTable(TABLE_NAME);//
        SqlInfo infosql = dbTool.ExecuteQuery(strsql, false);
        int count = dbTool.GetCount(infosql);

        bool ret = dbTool.MoveToFirst(infosql);
        Debug.Log("strsql=" + strsql + " count=" + count + " ret=" + ret);
        if (ret == false)
        {
            return listRet;
        }
        while (true)// 循环遍历数据 
        {
            Debug.Log("GetAllItem reading");
            DBWordItemInfo infoDB = new DBWordItemInfo();
            // ReadInfo(infoDB, infosql);
            infoDB.date = dbTool.GetString(infosql, KEY_date);
            WordItemInfo info = new WordItemInfo();
            // info.id = infoDB.id;
            info.dbInfo = infoDB;
            listRet.Add(info);
            if (!dbTool.MoveToNext(infosql))
            {
                break;
            }
        }


        CloseDB();
        Debug.Log("GetAllDate:" + listRet.Count);
        return listRet;


    }

    public List<WordItemInfo> GetItemsOfDate(string date)
    {
        string strsql = "select * from " + TABLE_NAME + " where date = '" + date + "'" + "order by addtime desc";

        List<WordItemInfo> listRet = new List<WordItemInfo>();
        OpenDB();
        //SqliteDataReader reader = dbTool.ReadFullTable(TABLE_NAME);//
        SqlInfo infosql = dbTool.ExecuteQuery(strsql, false);
        Debug.Log("GetAllItem start read");
        bool ret = dbTool.MoveToFirst(infosql);
        if (ret == false)
        {
            return listRet;
        }
        while (true)// 循环遍历数据 
        {
            DBWordItemInfo infoDB = new DBWordItemInfo();
            ReadInfo(infoDB, infosql);
            WordItemInfo info = new WordItemInfo();
            info.id = infoDB.id;
            info.dbInfo = infoDB;
            listRet.Add(info);
            if (!dbTool.MoveToNext(infosql))
            {
                break;
            }
        }


        CloseDB();
        Debug.Log("GetItemsOfDate:" + listRet.Count);
        return listRet;
    }


    public List<WordItemInfo> GetItemsOfWord(string word)
    {
        string strsql = "select * from " + TABLE_NAME + " where id = '" + word + "'" + "order by addtime desc";
        List<WordItemInfo> listRet = new List<WordItemInfo>();
        OpenDB();
        //SqliteDataReader reader = dbTool.ReadFullTable(TABLE_NAME);//
        SqlInfo infosql = dbTool.ExecuteQuery(strsql, false);
        Debug.Log("GetAllItem start read");
        bool ret = dbTool.MoveToFirst(infosql);
        if (ret == false)
        {
            return listRet;
        }
        while (true)// 循环遍历数据 
        {
            DBWordItemInfo infoDB = new DBWordItemInfo();
            ReadInfo(infoDB, infosql);
            WordItemInfo info = new WordItemInfo();
            info.id = infoDB.id;
            info.dbInfo = infoDB;
            listRet.Add(info);
            if (!dbTool.MoveToNext(infosql))
            {
                break;
            }
        }


        CloseDB();
        Debug.Log("GetItemsOfDate:" + listRet.Count);
        return listRet;
    }


    public List<object> Search(string word)
    {
        List<object> listRet = new List<object>();
        if (Common.isBlankString(word))
        {
            return listRet;
        }
        string strsearch = word;
        string strsql = "SELECT * FROM " + TABLE_NAME + " WHERE title LIKE '%" + strsearch + "%'" + " OR id LIKE '%" + strsearch + "%'";
        //  strsql = "SELECT * FROM " + TABLE_NAME;
        // strsql = "SELECT rowid , * FROM " + TABLE_NAME;//SELECT rowid, * FROM "TableIdiom"
        //  strsql = "select * from TableIdiom where title like '%一%'";
        OpenDB();

        SqlInfo infosql = dbTool.ExecuteQuery(strsql, false);
        bool ret = dbTool.MoveToFirst(infosql);
        if (ret == false)
        {
            return listRet;
        }
        while (true)// 循环遍历数据 
        {
            DBWordItemInfo info = new DBWordItemInfo();
            ReadInfo(info, infosql);
            listRet.Add(info);
            if (!dbTool.MoveToNext(infosql))
            {
                break;
            }
        }
        //   reader.Release();

        CloseDB();
        return listRet;
    }

}



