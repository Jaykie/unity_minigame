﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class WordDB : DBBaseWord
{      public string dbFileName;
  
    string[] item_col = new string[] { KEY_id, KEY_title, KEY_translation, KEY_change, };
    //string[] item_col = new string[] { KEY_id, KEY_intro, KEY_album, KEY_translation, KEY_author, KEY_year, KEY_style, KEY_pinyin, KEY_appreciation, KEY_head, KEY_end, KEY_tips, KEY_date, KEY_addtime };
    //string[] item_coltype = new string[] { KEY_text, KEY_text, KEY_text, KEY_text, KEY_text, KEY_text, KEY_text, KEY_text, KEY_text, KEY_text, KEY_text, KEY_text, KEY_text, KEY_text };
    static public string strSaveWordShotDir//字截图保存目录
    {
        get
        {
            return Application.temporaryCachePath + "/SaveItem";
        }
    }

    public string dbFilePath
    {
        get
        {
            string appDBPath = Application.temporaryCachePath + "/" + dbFileName;
            Debug.Log("appDBPath=" + appDBPath);
            return appDBPath;
        }
    }
    static WordDB _main = null;
    static bool isInited = false;
    public static WordDB main
    {
        get
        {

            if (_main == null)
            {
                _main = new WordDB();
                Debug.Log("DBWord main init");
                _main.TABLE_NAME = "TableWord";
                _main.dbFileName = "Word_" + Common.appKeyName + ".db";
                _main.Init();
            }

            return _main;
        }



    }
    public void Init()
    {
        isNeedCopyFromAsset = false;
        if (Application.isEditor || Common.isiOS)
        {
            CopyDbFileFromResource();
        }
        CreateDb();
        CreateTable(item_col);
    }

    //2017.1.10 to 1.10
    static public string getDateDisplay(string date)
    {
        int idx = date.IndexOf(".");
        if (idx >= 0)
        {
            string str = date.Substring(idx + 1);
            return str;
        }
        return date;
    }

    //{ "id", "intro", "album", "translation", "author", "year", "style", "pinyin", "appreciation", "head", "end", "tips", "date", "addtime" };
 

    public override void AddItem(DBWordItemInfo info)
    {
        OpenDB();
        int lengh = item_col.Length;
        string[] values = new string[lengh];
        //id,filesave,date,addtime 
        values[0] = info.id;
        //values[0] = "性";//ng

        values[1] = info.title;
        values[2] = info.translation;
        values[3] = info.change;
        // int year = System.DateTime.Now.Year;
        // int month = System.DateTime.Now.Month;
        // int day = System.DateTime.Now.Day;
        // string str = year + "." + month + "." + day;
        // Debug.Log("date:" + str);
        // values[lengh - 2] = str;
        // long time_ms = Common.GetCurrentTimeMs();//GetCurrentTimeSecond
        // values[lengh - 1] = time_ms.ToString();


        dbTool.InsertInto(TABLE_NAME, values);

        CloseDB();
        //  GetItemsByWord();


    }

    public override void ReadInfo(DBWordItemInfo info, SqlInfo infosql)
    {
        info.id = dbTool.GetString(infosql, KEY_id);
        info.title = dbTool.GetString(infosql, KEY_title);
        info.translation = dbTool.GetString(infosql, KEY_translation);
        info.change = dbTool.GetString(infosql, KEY_change);

        // info.pinyin = rd.GetString(KEY_pinyin);
        // Debug.Log("ReadInfo info.pinyin=" + info.pinyin);
        /* 

        */
        // info.addtime = dbTool.GetString(infosql, KEY_addtime);
        // info.date = dbTool.GetString(infosql, KEY_date);
    }
 
}

