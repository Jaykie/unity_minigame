﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class DBLoveold : DBBaseWord
{
    public string[] item_col = new string[] { KEY_id,KEY_date,KEY_addtime
 };
    //       public string[] item_col = new string[] { KEY_id, KEY_title, KEY_pinyin, KEY_album, KEY_translation, KEY_year, KEY_usage,  KEY_common_use, KEY_emotional, KEY_structure,
    //         KEY_near_synonym, KEY_antonym, KEY_example, KEY_correct_pronunciation,KEY_date,KEY_addtime
    //  };
    static DBLoveold _main = null;
    static bool isInited = false;
    public static DBLoveold main
    {
        get
        {
           if (_main==null)
            {
                isInited = true;
                _main = new DBLoveold();
                Debug.Log("DBLoveold main init");
                _main.TABLE_NAME = "TableWord";
               _main.dbFileName = "LoveDB_" + Common.appKeyName + ".db";
                // _main.CopyDbFileFromResource();
                _main.Init();
            }
            return _main;
        }


        //ng:
        //  get
        // {
        //     if (_main==null)
        //     {
        //         _main = new LoveDB();
        //         Debug.Log("LoveDB main init");
        //         _main.CreateDb();
        //     }
        //     return _main;
        // }
    }

    public void Init()
    {
        isNeedCopyFromAsset = false;
        CreateDb();
        CreateTable(item_col);
    }

    //{ "id", "intro", "album", "translation", "author", "year", "style", "pinyin", "appreciation", "head", "end", "tips", "date", "addtime" };
    public void AddItem(string id)
    {
        OpenDB();
        int lengh = item_col.Length;
        string[] values = new string[lengh];
        //id,filesave,date,addtime 

        values[0] = id;
        //values[0] = "性";//ng

        // values[1] = info.title;
        // values[2] = info.translation;
        // values[3] = info.change;



        // int year = System.DateTime.Now.Year;
        // int month = System.DateTime.Now.Month;
        // int day = System.DateTime.Now.Day;
        // string str = year + "." + month + "." + day;
        // Debug.Log("date:" + str);
        // values[lengh - 2] = str;
        // long time_ms = Common.GetCurrentTimeMs();//GetCurrentTimeSecond
        // values[lengh - 1] = time_ms.ToString();


        dbTool.InsertInto(TABLE_NAME, values);


        CloseDB();


    }

    public override void ReadInfo(DBWordItemInfo info, SqlInfo infosql)
    {

        info.id = dbTool.GetString(infosql, KEY_id);
        // info.title = dbTool.GetString(infosql, KEY_title);
        // info.translation = dbTool.GetString(infosql, KEY_translation);
        // info.change = dbTool.GetString(infosql, KEY_change);

    }

 
 

}

