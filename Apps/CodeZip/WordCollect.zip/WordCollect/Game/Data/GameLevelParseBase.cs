﻿using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System.Text;


public class GameLevelParseBase : LevelParseBase
{
      public string strWord3500;
     static public string[] arrayPunctuation = { "。", "？", "！", "，", "、", "；", "：" };
    public virtual void ParseItem(WordItemInfo info)
    {


    }

    public virtual void ParseItemDetal(WordItemInfo info)
    {


    }
    
     public int ParseGuankaDefault()
    {
        int count = 0;

        if ((listGuanka != null) && (listGuanka.Count != 0))
        {
            return listGuanka.Count;
        }
        // UpdateLanguage();
        listGuanka = new List<object>();
        int idx = LevelManager.main.placeLevel;
        LanguageManager.main.UpdateLanguage(idx);

        ItemInfo infoPlace = LevelManager.main.GetPlaceItemInfo(LevelManager.main.placeLevel);
        string filepath = CloudRes.main.rootPathGameRes + "/guanka/guanka_list_place" + idx + ".json";
        if (!FileUtil.FileIsExistAsset(filepath))
        {
            filepath = CloudRes.main.rootPathGameRes + "/guanka/item_" + infoPlace.id + ".json";
        }

        //
        //FILE_PATH
        string json = FileUtil.ReadStringAsset(filepath);

        JsonData root = JsonMapper.ToObject(json);
        string strPlace = infoPlace.id;
        JsonData items = root["items"];

        for (int i = 0; i < items.Count; i++)
        {
            JsonData item = items[i];
            WordItemInfo info = new WordItemInfo();
            // info.dbIdiomInfo = new IdiomItemInfo();
            info.dbInfo = new DBWordItemInfo();
            info.id = JsonUtil.JsonGetString(item, "id", "");
            //string str = "aa";// = languageGame.GetString(info.id);
            //Debug.Log(i + ":ParseGame:" + str);
            info.pic = CloudRes.main.rootPathGameRes + "/image/" + strPlace + "/" + info.id + ".png";
            info.icon = CloudRes.main.rootPathGameRes + "/image_thumb/" + strPlace + "/" + info.id + ".png";
            if (!FileUtil.FileIsExistAsset(info.icon))
            {
                info.icon = info.pic;
            }
            string key = "xiehouyu";
            if (JsonUtil.ContainsKey(item, key))
            {
                JsonData xiehouyu = item[key];
                for (int j = 0; j < xiehouyu.Count; j++)
                {
                    JsonData item_xhy = xiehouyu[j];
                    if (j == 0)
                    {
                        info.head = (string)item_xhy["content"];
                    }
                    if (j == 1)
                    {
                        info.end = (string)item_xhy["content"];
                    }
                }

            }

            key = "head";
            if (JsonUtil.ContainsKey(item, key))
            {
                //Riddle
                info.head = (string)item["head"];
                info.end = (string)item["end"];
                info.tips = (string)item["tips"];
                info.type = (string)item["type"];
            }

            if (Common.appKeyName == GameRes.GAME_IDIOM)
            {
                info.gameType = GameRes.GAME_TYPE_IMAGE;
            }
            // else if (Common.appKeyName == GameRes.GAME_POEM)
            // {
            //     info.gameType = GameRes.GAME_TYPE_POEM;
            // }
            else if (Common.appKeyName == GameRes.GAME_CONNECT)
            {
                info.gameType = GameRes.GAME_TYPE_CONNECT;
            }
            else
            {
                info.gameType = infoPlace.gameType;
            }

            if (Common.appKeyName == GameRes.GAME_POEM)
            {
                ParsePoemItem(info);
            }
            listGuanka.Add(info);
        }

        count = listGuanka.Count;

        for (int i = 0; i < listGuanka.Count; i++)
        {
            WordItemInfo info = listGuanka[i] as WordItemInfo;
            string word0 = GameAnswer.main.GetGuankaAnswer(info, false, 0);
            int idx1 = GetRandomOtherLevelIndex(i);
            WordItemInfo info1 = listGuanka[idx1] as WordItemInfo;
            string word1 = GameAnswer.main.GetGuankaAnswer(info1, false, 0);
            // word1 = word1.Substring(0, word1.Length / 2);
            string word = word0 + word1;
            if (Common.appKeyName == GameRes.GAME_POEM)
            {
                word = word0;
            }
            else
            {
                if (word.Length > GameAnswer.MAX_WORD)
                {
                    word = word0;
                }
            }

            Debug.Log("word = " + word);

            info.listLetter = new string[word.Length];
            for (int k = 0; k < word.Length; k++)
            {
                info.listLetter[k] = word.Substring(k, 1);
            }

            if (Common.appKeyName == GameRes.GAME_POEM)
            {
                info.listAnswer = new string[info.listPoemContent.Count];
                for (int k = 0; k < info.listPoemContent.Count; k++)
                {
                    PoemContentInfo infoPoem = info.listPoemContent[k];
                    Debug.Log("word answer = " + infoPoem.content);
                    info.listAnswer[k] = infoPoem.content;

                }
            }
            else
            {
                info.listAnswer = new string[1];
                info.listAnswer[0] = word0;
                // info.listAnswer[1] = word1;

            }


        }

        //word3500
        filepath = Common.GAME_DATA_DIR + "/words_3500.json";
        if (FileUtil.FileIsExistAsset(filepath))
        {
            json = FileUtil.ReadStringAsset(filepath);
            root = JsonMapper.ToObject(json);
            strWord3500 = (string)root["words"];
            Debug.Log(strWord3500);
        }


        Debug.Log("ParseGame::count=" + count);
        return count;
    }


   public  int GetRandomOtherLevelIndex(int level)
    {
        int total = listGuanka.Count;
        int size = total - 1;
        int[] idxTmp = new int[size];
        int idx = 0;
        for (int i = 0; i < total; i++)
        {
            if (i != level)
            {
                idxTmp[idx++] = i;
            }
        }

        int rdm = Random.Range(0, size);
        if (rdm >= size)
        {
            rdm = size - 1;
        }
        idx = idxTmp[rdm];
        return idx;
    }

     //诗词
    public void ParsePoemItem(WordItemInfo info)
    {
        string filepath = CloudRes.main.rootPathGameRes + "/guanka/poem/" + info.id + ".json";
        if (!FileUtil.FileIsExistAsset(filepath))
        {
            return;
        }
        //
        //FILE_PATH
        string json = FileUtil.ReadStringAsset(filepath);
        JsonData root = JsonMapper.ToObject(json);
        info.title = (string)root["title"];
        info.author = (string)root["author"];
        info.year = (string)root["year"];
        info.style = (string)root["style"];
        info.album = (string)root["album"];
        info.url = (string)root["url"];
        info.intro = (string)root["intro"];
        info.translation = (string)root["translation"];
        info.appreciation = (string)root["appreciation"];

        JsonData itemPoem = root["poem"];
        info.listPoemContent = new List<PoemContentInfo>();
        for (int i = 0; i < itemPoem.Count; i++)
        {
            JsonData item = itemPoem[i];
            string str = (string)item["content"];
            string[] strlist = new string[1];
            strlist[0] = str;
            if (Common.appKeyName == GameRes.GAME_POEM)
            {
                strlist = str.Split('，');
            }
            for (int k = 0; k < strlist.Length; k++)
            {

                PoemContentInfo infoPoem = new PoemContentInfo();
                infoPoem.content = strlist[k];
                infoPoem.pinyin = (string)item["pinyin"];
                bool isSkip = JsonUtil.JsonGetBool(item, "skip", false);
                if (Common.appKeyName == GameRes.GAME_POEM)
                {
                    infoPoem.content = FilterPunctuation(infoPoem.content);
                    // isSkip = false;
                }

                if (!isSkip)
                {
                    info.listPoemContent.Add(infoPoem);
                }

            }
        }
    }
    
    //过滤标点符号 点号：句号（ 。）、问号（ ？）、感叹号（ ！）、逗号（ ，）顿号（、）、分号（；）和冒号（：）。
    public string FilterPunctuation(string str)
    {
        string ret = str;

        foreach (string item in arrayPunctuation)
        {
            ret = ret.Replace(item, "");
        }
        return ret;
    }

}
