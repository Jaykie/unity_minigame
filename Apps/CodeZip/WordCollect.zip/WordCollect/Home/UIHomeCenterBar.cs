﻿using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Moonma.IAP;
using Moonma.Share;
using UnityEngine;
using UnityEngine.UI;

public class UIHomeCenterBar : UIView
{

    public Button btnLearn;
    public Button btnAdVideo;
    public Button btnAddLove;

    public Button btnPlay;
    void Awake()
    {
        // if (!Config.main.APP_FOR_KIDS)
        {
            btnLearn.gameObject.SetActive(false);
        }

        if (btnAdVideo != null)
        {
            btnAdVideo.gameObject.SetActive(true);
            if ((Common.noad) || (!AppVersion.appCheckHasFinished))
            {
                btnAdVideo.gameObject.SetActive(false);
            }
            if (Common.isAndroid)
            {
                if (Config.main.channel == Source.GP)
                {
                    //GP市场不显示
                    btnAdVideo.gameObject.SetActive(false);
                }
            }
        }
        if ((Common.appKeyName == GameRes.GAME_Image) || (Common.appKeyName == GameRes.GAME_POEM) || (Common.appKeyName == GameRes.GAME_WORDCONNECT))
        {
            btnAddLove.gameObject.SetActive(false);
        }

        if (!AppVersion.appCheckHasFinished)
        {
            btnAddLove.gameObject.SetActive(false);
        }

    }
    // Use this for initialization
    void Start()
    {
        LayOut();
        Invoke("LayOut", 0.1f);

    }


    public override void LayOut()
    {
        base.LayOut();
        float x = 0, y = 0, w = 0, h = 0;
        LayOutGrid ly = this.GetComponent<LayOutGrid>();
        RectTransform rctranPlay = btnPlay.transform as RectTransform;
        if (ly != null)
        {

            ly.enableHide = false;
            int child_count = ly.GetChildCount(false);
            if (Device.isLandscape)
            {
                ly.row = 1;
                ly.col = child_count;
            }
            else
            {

                ly.row = 2;
                ly.col = 2;
            }

            RectTransform rcran = ly.GetComponent<RectTransform>();
            w = rcran.sizeDelta.x;
            float item_w = rctranPlay.rect.width;
            h = ly.row * (item_w + ly.space.y);
            rcran.sizeDelta = new Vector2(w, h);
            ly.LayOut();

            base.LayOut();
        }
    }

    public void OnClickBtnLearn()
    {

        if (this.controller != null)
        {
            NaviViewController navi = this.controller.naviController;
            //  navi.Push(LearnViewController.main);

        }
    }

    public void OnClickBtnAdVideo()
    {
        AdKitCommon.main.ShowAdVideo();
    }
    public void OnClickBtnAddLove()
    {
        if (this.controller != null)
        {
            NaviViewController navi = this.controller.naviController;
            navi.Push(LoveViewController.main);
        }
    }


    public void OnClickBtnPlay()
    {

        Debug.Log("OnClickBtnPlay");
        if (this.controller != null)
        {
            NaviViewController navi = this.controller.naviController;
            int total = LevelManager.main.placeTotal;
            if (total > 1)
            {
                navi.Push(PlaceViewController.main);
            }
            else
            {
                navi.Push(GuankaViewController.main);
            }
        }
    }

}
