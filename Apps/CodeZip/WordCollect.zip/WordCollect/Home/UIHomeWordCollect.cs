﻿using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public class UIHomeWordCollect : UIHomeBase
{
    float timeAction;
    bool isActionFinish; 
    public GameObject objLogo;
    public UIImage imageBg2;
    //public ActionHomeBtn actionBtnLearn;
    public void Awake()
    {
        base.Awake();
        // TextureUtil.UpdateRawImageTexture(imageBg, AppRes.IMAGE_HOME_BG, true);

        
        if(!ImageRes.main.IsContainsKey("V_startup"))
        {
            // AppSceneBase.main.UpdateWorldBg(AppRes.IMAGE_HOME_BG);
            string pic = AppRes.IMAGE_HOME_BG;
            imageBg2.UpdateImage(pic);
        } 
        string appname = Common.GetAppNameDisplay();
        TextName.text = appname;
        timeAction = 0.3f;
        isActionFinish = false;

        //  TextName.color = ColorConfig.main.GetColor(GameRes.KEY_COLOR_HomeName, Color.white);
        LoadPrefab();
 
 
    }

    // Use this for initialization
    public void Start()
    {
        base.Start();
        isActionFinish = false;
        // RunActionImageName();
        //   actionBtnLearn.RunAction();
        LayOut();
        // WordItemInfo infoItem = DBWord.main.GetItem("TEN");
        // Debug.Log(" id=" + infoItem.id + " title=" + infoItem.title + " translation=" + infoItem.translation);
        OnUIDidFinish();
    }

    void LoadPrefab()
    {
        float x, y, z;
    }
    // Update is called once per frame
    void Update()
    {
        UpdateBase();
    }
 
    public override void LayOut()
    {
        base.LayOut(); 
    }


}
