using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Vectrosity;
/*
参考游戏： 交叉线!
https://www.taptap.com/app/64361

线段交叉算法：
https://www.cnblogs.com/sparkleDai/p/7604895.html
https://blog.csdn.net/rickliuxiao/article/details/6259322

*/


public class LineInfo
{
    public List<Vector3> listPoint;
    public VectorLine line;

    //dot
    public int idxStart;
    public int idxEnd;
    public bool isCross;
    public Vector3 ptStart;
    public Vector3 ptEnd;

}

public class GameStock : GameBase
{ 
    /// Awake is called when the script instance is being loaded.
    /// </summary>
    void Awake()
    {
    
        LayOut();
    }
    /// <summary>
    /// Start is called on the frame when a script is enabled just before
    /// any of the Update methods is called the first time.
    /// </summary>
    void Start()
    {
        LayOut();
    }

    void OnDestroy()
    {
       
    }

    public override void LayOut()
    {
        base.LayOut();
      

    }
    public void UpdateGuankaLevel(int level)
    {
      
    } 
 
}

