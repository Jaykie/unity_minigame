﻿using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public class UIHomeStock : UIHomeBase
{
    float timeAction;
    bool isActionFinish;  

    //public ActionHomeBtn actionBtnLearn;
    public void Awake()
    {
        base.Awake();
        // TextureUtil.UpdateRawImageTexture(imageBg, AppRes.IMAGE_HOME_BG, true);
        AppSceneBase.main.UpdateWorldBg(AppRes.IMAGE_HOME_BG);
        string appname = Common.GetAppNameDisplay();
        TextName.text = appname;
        timeAction = 0.3f;
        isActionFinish = false;

        // actionBtnLearn.gameObject.SetActive(Config.main.APP_FOR_KIDS);


        // actionBtnLearn.ptNormal = layoutBtn.GetItemPostion(0, 0);
        LoadPrefab();

 
    }

    // Use this for initialization
    public void Start()
    {
        base.Start();
        isActionFinish = false; 
        LayOut();

    }

    void LoadPrefab()
    {
        float x, y, z;


    }
    // Update is called once per frame
    void Update()
    {
        UpdateBase();
    }
 
 

 

    public override void LayOut()
    {
        base.LayOut();
   
    }

}
